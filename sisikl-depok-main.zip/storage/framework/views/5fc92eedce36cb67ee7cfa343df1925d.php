<div class="px-3 sm:px-6 py-3">
    <div class="breadcrumbs text-sm">
        <ul>
            <li><a class="text-blue-500" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li><a class="text-blue-500" href="<?php echo e($showRoute); ?>">Hasil Inspeksi</a></li>
            <li>Ubah Data Formulir</li>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sisikl-depok-main\resources\views/components/breadcrumb/edit-inspection.blade.php ENDPATH**/ ?>