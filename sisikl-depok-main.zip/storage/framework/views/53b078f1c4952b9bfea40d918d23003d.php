<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab = $attributes; } ?>
<?php $component = App\View\Components\Section\PageHeader::resolve(['title' => 'Ubah Informasi / Penilaian Pasar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab)): ?>
<?php $attributes = $__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab; ?>
<?php unset($__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab)): ?>
<?php $component = $__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab; ?>
<?php unset($__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal4a9e8e9ad463b1367a80b54f17b1bd04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a9e8e9ad463b1367a80b54f17b1bd04 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb\EditInspection::resolve(['showRoute' => ''.e(route('pasar.show', ['pasar' => $form_data['id']])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.edit-inspection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb\EditInspection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a9e8e9ad463b1367a80b54f17b1bd04)): ?>
<?php $attributes = $__attributesOriginal4a9e8e9ad463b1367a80b54f17b1bd04; ?>
<?php unset($__attributesOriginal4a9e8e9ad463b1367a80b54f17b1bd04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a9e8e9ad463b1367a80b54f17b1bd04)): ?>
<?php $component = $__componentOriginal4a9e8e9ad463b1367a80b54f17b1bd04; ?>
<?php unset($__componentOriginal4a9e8e9ad463b1367a80b54f17b1bd04); ?>
<?php endif; ?>

<form action="<?php echo e(route('pasar.update', ['pasar' => $form_data['id']])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <!-- INFORMASI UMUM -->
    <div class="px-3 pb-3 sm:px-6 sm:pb-6">
        <div class="bg-white rounded-xl p-6 sm:p-8">
            <h1 class="font-bold text-xl">Informasi Umum</h1>
            <hr class="my-5" />
            <div class="grid grid-flow-row md:grid-cols-2 gap-5">
                <?php $__currentLoopData = $informasi_umum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php switch($form_input['name']):
                case ('instansi-pemeriksa'): ?>
                <?php if (isset($component)) { $__componentOriginal7a43af28f7607ede406dd2f626811c9e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a43af28f7607ede406dd2f626811c9e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.instansi-pemeriksa.edit','data' => ['data' => $form_data['instansi-pemeriksa']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.instansi-pemeriksa.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($form_data['instansi-pemeriksa'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a43af28f7607ede406dd2f626811c9e)): ?>
<?php $attributes = $__attributesOriginal7a43af28f7607ede406dd2f626811c9e; ?>
<?php unset($__attributesOriginal7a43af28f7607ede406dd2f626811c9e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a43af28f7607ede406dd2f626811c9e)): ?>
<?php $component = $__componentOriginal7a43af28f7607ede406dd2f626811c9e; ?>
<?php unset($__componentOriginal7a43af28f7607ede406dd2f626811c9e); ?>
<?php endif; ?>
                <?php break; ?>

                <?php case ('kecamatan'): ?>
                <div class="input-group">
                    <label for="kec"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="kec" class="select select-bordered" required>
                        <option value="">Pilih Kecamatan</option>
                    </select>
                    <!-- Hidden input as backup to ensure kecamatan value is always sent -->
                    <input type="hidden" id="kecamatan-backup" name="kecamatan-backup" value="<?php echo e($form_data['kecamatan']); ?>" />
                </div>
                <?php break; ?>

                <?php case ('kelurahan'): ?>
                <div class="input-group">
                    <label for="kel"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="kel" class="select select-bordered" required>
                        <option value="">Pilih Kelurahan</option>
                    </select>
                    <!-- Hidden input as backup to ensure kelurahan value is always sent -->
                    <input type="hidden" id="kelurahan-backup" name="kelurahan-backup" value="<?php echo e($form_data['kelurahan']); ?>" />
                </div>
                <?php break; ?>

                <?php case ('status-operasi'): ?>
                <div class="input-group">
                    <label for="status-operasi"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="status-operasi" class="select select-bordered" required>
                        <option value="" disabled selected>Pilih Status</option>
                        <option <?php if($form_data['status-operasi']): ?> selected <?php endif; ?> value="1">Masih Beroperasi</option>
                        <option <?php if(!$form_data['status-operasi']): ?> selected <?php endif; ?> value="0">Tidak Beroperasi</option>
                    </select>
                </div>
                <?php break; ?>

                <?php case ('koordinat'): ?>
                <div class="input-group">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <div class="join">
                        <input type="<?php echo e($form_input['type']); ?>" id="koordinat" name="koordinat" class="join-item w-full" placeholder="-6.324667, 106.891268" required value="<?php echo e($form_data['koordinat']); ?>" required />
                        <button onclick="get_lat_long.showModal()" type="button" class="join-item btn btn-neutral">
                            <i class="ri-search-2-line"></i>
                        </button>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('tanggal-penilaian'): ?>
                <div class="input-group">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="date" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" value="<?php echo e($form_data[$form_input['name']] ? $form_data[$form_input['name']]->format('Y-m-d') : ''); ?>" required />
                </div>
                <?php break; ?>

                <?php default: ?>
                <div class="input-group">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="<?php echo e($form_input['type']); ?>" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" value="<?php echo e($form_data[$form_input['name']]); ?>" required />
                </div>
                <?php endswitch; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- FORM PENILAIAN -->
    <div class="px-3 pb-3 sm:px-6 sm:pb-6 flex flex-wrap lg:flex-nowrap gap-5">
        <div class="bg-white rounded-xl flex-grow pb-4">
            <div class="p-6 sm:p-8">
                <h1 class="font-bold text-xl">Formulir Penilaian</h1>
            </div>

            <?php $__currentLoopData = $form_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $form_input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php switch($form_input['type']):

            case ('h2'): ?>
            <div id="<?php echo e($form_input['id']); ?>" class="text-white bg-black/40 px-6 sm:px-8 py-4 mb-6 <?php if($index > 0): ?> mt-10 <?php endif; ?>">
                <h2 class="font-semibold text-lg relative"><?php echo e($form_input['label']); ?></h2>
            </div>
            <?php break; ?>

            <?php case ('h3'): ?>
            <div id="<?php echo e($form_input['id']); ?>" class="px-6 sm:px-8 pt-2">
                <h3 class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6"><?php echo e($form_input['label']); ?></h3>
            </div>
            <?php break; ?>

            <?php case ('h4'): ?>
            <div class="px-6 sm:px-8 pb-3 mt-4">
                <h4 class="text-base underline underline-offset-8"><?php echo e($form_input['label']); ?> :</h4>
            </div>
            <?php break; ?>

            <?php case ('h5'): ?>
            <div class="px-6 sm:px-8 pb-3 mt-4">
                <h5 class="text-sm font-semibold"><?php echo e($form_input['label']); ?> :</h5>
            </div>
            <?php break; ?>

            <?php case ('select'): ?>
            <div class="px-3 sm:px-8">
                <div class="p-4 border rounded mb-3">
                    <div class="flex flex-col-reverse sm:flex-row justify-between gap-2 font-medium">
                        <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                        <span class="badge badge-outline badge-error">+<?php echo e($form_input['option'][1]['value']); ?></span>
                    </div>
                    <hr class="mt-3 mb-2" />
                    <div class="flex gap-5">
                        <div class="form-control">
                            <label class="label cursor-pointer justify-start gap-2">
                                <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="<?php echo e($form_input['option'][0]['value']); ?>" <?php if($form_data[$form_input['name']] == $form_input['option'][0]['value']): ?> checked <?php endif; ?> />
                                <span class="label-text"><?php echo e($form_input['option'][0]['label']); ?></span>
                            </label>
                        </div>
                        <div class="form-control">
                            <label class="label cursor-pointer justify-start gap-2">
                                <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-error" value="<?php echo e($form_input['option'][1]['value']); ?>" <?php if($form_data[$form_input['name']] == $form_input['option'][1]['value']): ?> checked <?php endif; ?> />
                                <span class="label-text"><?php echo e($form_input['option'][1]['label']); ?></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <?php break; ?>

            <?php default: ?>

            <?php endswitch; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div id="catatan-lain" class="px-6 sm:px-8 pt-2">
                <label for="catatan-lain" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Hasil IKL</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="catatan-lain" id="catatan-lain" class="resize-none h-52" required placeholder="Catatan mengenai hasil inpeksi lingkungan kesehatan..."><?php echo e($form_data['catatan-lain']); ?></textarea>
                </div>
            </div>

            <div id="rencana-tindak-lanjut" class="px-6 sm:px-8 pt-2">
                <label for="rencana-tindak-lanjut" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Rencana Tindak Lanjut</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="rencana-tindak-lanjut" id="rencana-tindak-lanjut" class="resize-none h-52" required placeholder="Rencana untuk tindak lanjut kedepannya setelah inpeksi lingkungan kesehatan..."><?php echo e($form_data['rencana-tindak-lanjut']); ?></textarea>
                </div>
            </div>
        </div>

        <div class="sticky top-5 h-fit min-w-72 w-full lg:w-fit">
            <div class="bg-white rounded-xl p-6 max-h-[30rem] overflow-y-auto hidden lg:block mb-5">
                <?php $__currentLoopData = $form_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($heading['type'] == 'h2'): ?>
                <a href="#<?php echo e($heading['id']); ?>" class="text-blue-500 text-sm my-2 block ml-2 underline font-semibold"><?php echo e($heading['label']); ?></a>
                <?php elseif($heading['type'] == 'h3'): ?>
                <a href="#<?php echo e($heading['id']); ?>" class="text-blue-400 text-xs my-1 block ml-4 underline"><?php echo e($heading['label']); ?></a>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <a href="#catatan-lain" class="text-blue-500 text-sm my-2 block ml-2 underline">Hasil IKL</a>
                <a href="#rencana-tindak-lanjut" class="text-blue-500 text-sm my-2 block ml-2 underline">Rencana Tindak Lanjut</a>
            </div>
            <button class="btn btn-primary btn-block" name="action" value="update">SIMPAN PENILAIAN</button>
            <button type="button" class="btn btn-info btn-outline btn-block mt-5" onclick="showDuplicateConfirmation()">DUPLIKAT PENILAIAN</button>
        </div>

    </div>
</form>

<?php if (isset($component)) { $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $attributes = $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $component = $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal4f79666d4f834fb25649c1efa5f462ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f79666d4f834fb25649c1efa5f462ef = $attributes; } ?>
<?php $component = App\View\Components\Modal\GetLatLong::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.get-lat-long'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\GetLatLong::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f79666d4f834fb25649c1efa5f462ef)): ?>
<?php $attributes = $__attributesOriginal4f79666d4f834fb25649c1efa5f462ef; ?>
<?php unset($__attributesOriginal4f79666d4f834fb25649c1efa5f462ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f79666d4f834fb25649c1efa5f462ef)): ?>
<?php $component = $__componentOriginal4f79666d4f834fb25649c1efa5f462ef; ?>
<?php unset($__componentOriginal4f79666d4f834fb25649c1efa5f462ef); ?>
<?php endif; ?>

<script src="<?php echo e(asset('js/getDistrictsAndVillages.js')); ?>"></script>
<script>
    $(document).ready(function() {
        let kecVal = "<?php echo e($form_data['kecamatan']); ?>";
        let kelVal = "<?php echo e($form_data['kelurahan']); ?>";
        
        console.log('Edit form initialized with:', { kecVal, kelVal });

        // Function to populate kecamatan dropdown with existing value
        function populateKecamatan() {
            if (kecamatan.length > 0) {
                let options = '<option value="">Pilih Kecamatan</option>';
                
                kecamatan.forEach((el) => {
                    const selected = kecVal == el.name ? 'selected' : '';
                    options += `<option value="${el.name}" ${selected}>${el.name}</option>`;
                });
                
                $("#kec").html(options);
                $("#kec").prop('disabled', false);
                
                // If there's a pre-selected kecamatan, load its kelurahan
                if (kecVal) {
                    populateKelurahan(kecVal);
                }
                
                return true;
            }
            return false;
        }
        
        // Function to populate kelurahan dropdown
        function populateKelurahan(kecamatanName) {
            const selectedKec = kecamatan.find((el) => el.name === kecamatanName);
            
            if (!selectedKec) {
                console.error('Kecamatan not found:', kecamatanName);
                $("#kel").html('<option value="">Kecamatan tidak ditemukan</option>');
                $("#kel").prop('disabled', true);
                return;
            }
            
            $("#kel").html('<option value="">Memuat kelurahan...</option>');
            $("#kel").prop('disabled', true);
            
            fetch(`https://dev4ult.github.io/api-wilayah-indonesia/api/villages/${selectedKec.id}.json`)
                .then((response) => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then((villages) => {
                    let options = '<option value="">Pilih Kelurahan</option>';
                    
                    villages.forEach((el) => {
                        const selected = kelVal == el.name ? 'selected' : '';
                        options += `<option value="${el.name}" ${selected}>${el.name}</option>`;
                    });
                    
                    $("#kel").html(options);
                    $("#kel").prop('disabled', false);
                    
                    console.log('Kelurahan loaded successfully:', villages.length, 'items');
                })
                .catch((error) => {
                    console.error('Error loading villages:', error);
                    $("#kel").html('<option value="">Gagal memuat kelurahan</option>');
                    $("#kel").prop('disabled', false);
                });
        }
        
        // Wait for kecamatan data to be loaded
        let checkKec = setInterval(function() {
            if (populateKecamatan()) {
                clearInterval(checkKec);
                console.log('Kecamatan data loaded and populated');
            } else {
                console.log('Waiting for kecamatan data...');
            }
        }, 500)

        // Handle kecamatan change event
        $("#kec").on('change', function() {
            let selectedValue = $(this).val();
            console.log('Kecamatan changed to:', selectedValue);
            
            if (selectedValue) {
                populateKelurahan(selectedValue);
            } else {
                $("#kel").html('<option value="">Pilih Kelurahan</option>');
                $("#kel").prop('disabled', true);
            }
        });
        
        // Fallback timeout - give more time for edit forms
        setTimeout(() => {
            if ($("#kec option").length <= 1) {
                console.warn('Kecamatan data still not loaded after 15 seconds, trying fallback');
                // Try to preserve existing values
                if (kecVal) {
                    $("#kec").html(`<option value="${kecVal}" selected>${kecVal}</option>`);
                }
                if (kelVal) {
                    $("#kel").html(`<option value="${kelVal}" selected>${kelVal}</option>`);
                }
            }
        }, 15000);
         
         // Form submission handler to ensure kecamatan and kelurahan values are preserved
         $('form').on('submit', function(e) {
             const kecSelect = $('#kec');
             const kecBackup = $('#kecamatan-backup');
             const kelSelect = $('#kel');
             const kelBackup = $('#kelurahan-backup');
             
             // If kecamatan dropdown is empty or not loaded, use backup value
             if (!kecSelect.val() || kecSelect.val() === '' || kecSelect.val() === 'Pilih Kecamatan') {
                 if (kecBackup.val()) {
                     console.log('Using backup kecamatan value:', kecBackup.val());
                     // Create a temporary hidden input with the backup value
                     $('<input>').attr({
                         type: 'hidden',
                         name: 'kecamatan',
                         value: kecBackup.val()
                     }).appendTo(this);
                 }
             }
             
             // If kelurahan dropdown is empty or not loaded, use backup value
             if (!kelSelect.val() || kelSelect.val() === '' || kelSelect.val() === 'Pilih Kelurahan') {
                 if (kelBackup.val()) {
                     console.log('Using backup kelurahan value:', kelBackup.val());
                     // Create a temporary hidden input with the backup value
                     $('<input>').attr({
                         type: 'hidden',
                         name: 'kelurahan',
                         value: kelBackup.val()
                     }).appendTo(this);
                 }
             }
         });
    });

    function validateDuplicate() {
        const kecamatan = document.getElementById('kec').value;
        const kelurahan = document.getElementById('kel').value;
        
        if (!kecamatan || kecamatan === '' || kecamatan === 'Pilih Kecamatan') {
            alert('Kecamatan harus dipilih sebelum melakukan duplikasi penilaian');
            return false;
        }
        
        if (!kelurahan || kelurahan === '' || kelurahan === 'Pilih Kelurahan') {
            alert('Kelurahan harus dipilih sebelum melakukan duplikasi penilaian');
            return false;
        }
        
        return true;
    }

    function showDuplicateConfirmation() {
        if (validateDuplicate()) {
            showConfirmationModal(
                'Duplikat Penilaian',
                'Apakah Anda yakin ingin membuat duplikat dari penilaian pasar ini? Data akan disalin dengan informasi yang sama.',
                function() {
                    // Create a new form for duplicate action
                    const originalForm = document.querySelector('form');
                    const formData = new FormData(originalForm);
                    
                    // Create new form for duplicate
                    const duplicateForm = document.createElement('form');
                    duplicateForm.method = 'POST';
                    duplicateForm.action = '<?php echo e(route("pasar.store")); ?>';
                    duplicateForm.style.display = 'none';
                    
                    // Add CSRF token
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = '<?php echo e(csrf_token()); ?>';
                    duplicateForm.appendChild(csrfInput);
                    
                    // Add action input
                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'duplicate';
                    duplicateForm.appendChild(actionInput);
                    
                    // Add original ID for reference
                    const idInput = document.createElement('input');
                    idInput.type = 'hidden';
                    idInput.name = 'original_id';
                    idInput.value = '<?php echo e($form_data["id"]); ?>';
                    duplicateForm.appendChild(idInput);
                    
                    // Copy all form data except _method
                    for (let [key, value] of formData.entries()) {
                        if (key !== '_method' && key !== '_token' && key !== 'action') {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = key;
                            input.value = value;
                            duplicateForm.appendChild(input);
                        }
                    }
                    
                    // Append and submit
                    document.body.appendChild(duplicateForm);
                    duplicateForm.submit();
                }
            );
        }
    }

    // Auto-calculate on page load if issued date already filled</script>
<script src="<?php echo e(asset('js/autosave-form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisikl-depok-main\resources\views/pages/inspection/pasar/edit.blade.php ENDPATH**/ ?>