<div class="input-group">
    <label for="instansi-pemeriksa">Instansi Pemeriksa</label>
    <select id="instansi-pemeriksa" name="instansi-pemeriksa" class="select select-bordered" required>
        <option value="" disabled selected>Pilih</option>
        <option value="Dinas Kesehatan">Dinas Kesehatan</option>
        <option value="Puskesmas">Puskesmas</option>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\sisikl-depok-main\resources\views/components/input/instansi-pemeriksa/create.blade.php ENDPATH**/ ?>