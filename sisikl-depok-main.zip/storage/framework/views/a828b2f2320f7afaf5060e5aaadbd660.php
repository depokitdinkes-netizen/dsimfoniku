<div class="input-group">
    <label for="instansi-pemeriksa">Instansi Pemeriksa</label>
    <select name="instansi-pemeriksa" id="instansi-pemeriksa" class="select select-bordered" required>
        <option value="" disabled>Pilih Instansi Pemeriksa</option>
        <option value="Dinas Kesehatan" <?php if(($form_data['instansi-pemeriksa'] ?? '')=='Dinas Kesehatan' ): ?> selected <?php endif; ?>>Dinas Kesehatan</option>
        <option value="Puskesmas" <?php if(($form_data['instansi-pemeriksa'] ?? '')=='Puskesmas' ): ?> selected <?php endif; ?>>Puskesmas</option>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\sisikl-depok-main\resources\views/components/input/instansi-pemeriksa/edit.blade.php ENDPATH**/ ?>