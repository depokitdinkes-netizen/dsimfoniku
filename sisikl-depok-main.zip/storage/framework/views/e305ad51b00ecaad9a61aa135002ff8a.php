<?php $__env->startSection('content'); ?>
<div class="p-3 sm:p-6 border-b flex items-center justify-between gap-5">
    <h1 class="font-extrabold sm:text-xl">Histori Hasil Inspeksi</h1>
    <img src="<?php echo e(asset('logo/depok-city.png')); ?>" alt="depok city" class="h-6 sm:h-9 object-cover" />
</div>

<div class="p-3 sm:p-6">
    <div class="flex justify-end gap-3 flex-wrap mb-6">
        <button class="btn btn-primary btn-outline" onclick="filter_history.showModal()">
            <i class="ri-equalizer-3-fill"></i>
            <span>FILTER</span>
        </button>
        <form method="GET" class="join">
            <button type="submit" class="btn btn-primary btn-square join-item">
                <i class="ri-search-line"></i>
            </button>
            <input type="text" name="s" class="input input-bordered join-item w-full" placeholder="Cari hasil inspeksi ..." />
        </form>

        <button class="btn btn-primary" onclick="export_history.showModal()">
            <span>RAW EXPORT</span>
            <i class="ri-upload-2-line"></i>
        </button>
    </div>

    <div class="overflow-x-auto mb-2 bg-white rounded-lg">
        <table class="table table-zebra">
            <thead>
                <tr>
                    <th></th>
                    <th>Nama Tempat</th>
                    <th>Nama Pemeriksa</th>
                    <th>Skor</th>
                    <th>Tanggal Pemeriksaan</th>
                    <th>Status Operasi</th>
                    <th>Status SLHS</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($inspections) == 0): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada hasil inspeksi yang dapat ditampilkan</td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $inspections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $inspection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($index + 1 + (($page_index - 1) * $dpp)); ?></th>
                    <td><i class="<?php echo e($inspection['icon']); ?> text-<?php echo e($inspection['color']); ?>"></i> <span><?php echo e($inspection['name']); ?></span></td>
                    <td><?php echo e($inspection['reviewer']); ?></td>
                    <td class="font-semibold"><?php echo e(number_format($inspection['score'], 0, ',', '.')); ?></td>
                    <td><?php echo e($inspection['date']); ?></td>
                    <td>
                        <?php if($inspection['operasi']): ?>
                        <p class="border-success border text-success font-medium px-3 py-1.5 rounded-full text-xs text-center">MASIH BEROPERASI</p>
                        <?php else: ?>
                        <p class="border-error border text-error font-medium px-1.5 py-1 rounded-full text-xs text-center">TIDAK BEROPERASI</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginal2cb09917c463a753a5d3502338d96dfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cb09917c463a753a5d3502338d96dfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status.slhs-badge','data' => ['slhsExpireDate' => $inspection['slhs_expire_date'] ?? null,'slhsIssuedDate' => $inspection['slhs_issued_date'] ?? null,'showTooltip' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status.slhs-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slhsExpireDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inspection['slhs_expire_date'] ?? null),'slhsIssuedDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inspection['slhs_issued_date'] ?? null),'showTooltip' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cb09917c463a753a5d3502338d96dfa)): ?>
<?php $attributes = $__attributesOriginal2cb09917c463a753a5d3502338d96dfa; ?>
<?php unset($__attributesOriginal2cb09917c463a753a5d3502338d96dfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cb09917c463a753a5d3502338d96dfa)): ?>
<?php $component = $__componentOriginal2cb09917c463a753a5d3502338d96dfa; ?>
<?php unset($__componentOriginal2cb09917c463a753a5d3502338d96dfa); ?>
<?php endif; ?>
                    </td>
                    <td class="flex gap-1.5">
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->role != "USER"): ?>
                        <div class="tooltip tooltip-warning" data-tip="Ubah Informasi / Penilaian">
                            <a href="<?php echo e($inspection['sud'] . '/edit'); ?>" class="btn btn-warning btn-square">
                                <i class="ri-edit-fill"></i>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == "SUPERADMIN"): ?>
                        <form id="deleteForm<?php echo e($index); ?>" action="<?php echo e(url($inspection['sud'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <div class="tooltip tooltip-error" data-tip="Hapus Hasil Inspeksi">
                                <button type="button" class="btn btn-error btn-outline btn-square" onclick="showDeleteConfirmation('<?php echo e($inspection['name']); ?>', <?php echo e($index); ?>)">
                                    <i class="ri-delete-bin-6-line"></i>
                                </button>
                            </div>
                        </form>
                        <?php endif; ?>
                        <?php endif; ?>

                        <div class="tooltip" data-tip="Lihat Hasil Inspeksi">
                            <a href="<?php echo e($inspection['sud']); ?>" class="btn btn-neutral">
                                <i class="ri-info-i"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

    <div class="flex gap-3 mt-5 items-center justify-end">
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->role == "SUPERADMIN"): ?>
        <a href="<?php echo e(route('archived')); ?>" class="btn btn-primary btn-outline">ARCHIVED INSPEKSI</a>
        <?php endif; ?>
        <?php endif; ?>

        <div class="join">
            <?php if($page_index != 1): ?>
            <a href="<?php echo e(route('history') . '?p=' . (int) $page_index - 1); ?>" class="join-item btn rounded">
                <i class="ri-arrow-left-s-line"></i>
            </a>
            <a href="<?php echo e(route('history') . '?p=' . (int) $page_index - 1); ?>" class="join-item btn rounded">
                <?php echo e((int) $page_index - 1); ?>

            </a>
            <?php endif; ?>
            <button type="button" class="join-item btn rounded btn-active"><?php echo e($page_index); ?></button>
            <?php if($page_index != $total_pages && $total_pages != 0): ?>
            <a href="<?php echo e(route('history') . '?p=' . (int) $page_index + 1); ?>" class="join-item btn rounded">
                <?php echo e((int) $page_index + 1); ?>

            </a>
            <a href="<?php echo e(route('history') . '?p=' . (int) $page_index + 1); ?>" class="join-item btn rounded">
                <i class="ri-arrow-right-s-line"></i>
            </a>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('history')); ?>" class="join">
            <select class="select select-bordered join-item" name="dpp">
                <option value="5" <?php if($dpp==5): ?> selected <?php endif; ?>>5</option>
                <option value="15" <?php if($dpp==15): ?> selected <?php endif; ?>>15</option>
                <option value="25" <?php if($dpp==25): ?> selected <?php endif; ?>>25</option>
            </select>
            <button type="submit" class="btn btn-neutral join-item rounded">Set</button>
        </form>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal2b879a320b4c7309931c926bc74c6b94 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b879a320b4c7309931c926bc74c6b94 = $attributes; } ?>
<?php $component = App\View\Components\Modal\FilterHistory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.filter-history'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\FilterHistory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b879a320b4c7309931c926bc74c6b94)): ?>
<?php $attributes = $__attributesOriginal2b879a320b4c7309931c926bc74c6b94; ?>
<?php unset($__attributesOriginal2b879a320b4c7309931c926bc74c6b94); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b879a320b4c7309931c926bc74c6b94)): ?>
<?php $component = $__componentOriginal2b879a320b4c7309931c926bc74c6b94; ?>
<?php unset($__componentOriginal2b879a320b4c7309931c926bc74c6b94); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f = $attributes; } ?>
<?php $component = App\View\Components\Modal\ExportHistory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.export-history'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\ExportHistory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f)): ?>
<?php $attributes = $__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f; ?>
<?php unset($__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f)): ?>
<?php $component = $__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f; ?>
<?php unset($__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $attributes = $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $component = $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>

<script>
    function showDeleteConfirmation(inspectionName, formIndex) {
        showDeleteConfirmationModal(
            'Hapus Hasil Inspeksi',
            `Apakah Anda yakin ingin menghapus hasil inspeksi "${inspectionName}"? Data yang dihapus tidak dapat dikembalikan.`,
            function() {
                document.getElementById('deleteForm' + formIndex).submit();
            }
        );
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisikl-depok-main\resources\views/pages/history/index.blade.php ENDPATH**/ ?>